# Project 7 – De Boor Algorithm for B-Spline Curves

Rahul Nair (rahul.nair@digipen.edu)

## Overview

This project is an interactive C++ application built using the JUCE framework to visualize B-spline curves and the De Boor evaluation algorithm. Users click to place control points on a canvas and observe the resulting B-spline curve rendered in real time. A t-parameter slider scrubs along the curve, animating the full shell hierarchy of the De Boor algorithm at each position so the nested linear interpolation structure is visible at every step.

The application supports arbitrary non-decreasing knot vectors entered directly via the knot editor field and an adjustable degree slider (1–10).

## Running the Project

Double-click the `.exe` file to launch the application.

## Building the Project

Using the `Source` folder provided, generate a project using the JUCE Projucer and build from any compatible IDE.

## Architecture

The application follows the same modular, component-based structure as the previous projects:

- A UI/controller component manages user-facing controls:
  - Degree slider (`d`, range 1–10, default 3)
  - t-parameter slider with dynamic range label `[t_min, t_max]`
  - Knot vector editor (editable text field; press Enter to apply)
  - Clear button (removes all control points and resets knots)

- A single rendering and interaction component (`BSplineCanvas`) encapsulates:
  - Control point placement and drag interaction
  - Uniform default knot vector construction
  - Knot span lookup via binary search (`findSpan`)
  - De Boor NLI evaluation (`evalBSpline`) and shell computation (`computeShells`)
  - Full curve sampling and shell rendering at the current t

## Mathematics

### B-Spline Curve

Given `n+1` control points `P_0, ..., P_n`, degree `d`, and a non-decreasing knot vector:

```
T = [t_0, t_1, ..., t_{n+d+1}]
```

the B-spline curve is:

```
γ(t) = Σ_{i=0}^{n} P_i * N^d_i(t),   t ∈ [t_d, t_{n+1}]
```

where `N^d_i(t)` are the B-spline basis functions defined by the Cox–De Boor recursion:

```
N^0_i(t) = 1  if t_i ≤ t < t_{i+1},  else 0

N^d_i(t) = (t - t_i)/(t_{i+d} - t_i) * N^{d-1}_i(t)
          + (t_{i+d+1} - t)/(t_{i+d+1} - t_{i+1}) * N^{d-1}_{i+1}(t)
```

### Default (Uniform) Knot Vector

When no custom knots are provided, the canvas assigns:

```
t_i = i,   i = 0, ..., n + d + 1
```

This yields a uniform open B-spline. The parameter domain is `[t_d, t_{n+1}] = [d, n+1]`.

### De Boor Algorithm

For a given `t` in `[t_d, t_{n+1}]`, evaluation proceeds as follows:

**Step 1 — Find span:** locate the knot span index `J` such that `t ∈ [t_J, t_{J+1})` via binary search.

**Step 2 — Initialize active points:**

```
d_i^[0] = P_{J-d+i},   i = 0, ..., d
```

**Step 3 — Perform `d` stages of NLI:**

```
d_j^[p] = (1 - α) * d_j^[p-1] + α * d_{j+1}^[p-1]

where  α = (t - t_{J-d+p+j}) / (t_{J+j+1} - t_{J-d+p+j})
```

for `j = 0, ..., d-p` at each stage `p = 1, ..., d`. Zero-denominator cases (coincident knots) set `α = 0`.

**Step 4 — Result:**

```
γ(t) = d_0^[d]
```

### Shell Visualization

At each stage `p`, the intermediate points `d_0^[p], ..., d_{d-p}^[p]` form a shrinking polygon connecting toward `γ(t)`. These shells are drawn in distinct colors (orange → yellow → green → pink) at the current t-slider position, making the nested interpolation structure directly visible.

## Features

- Control points placed by clicking; curve renders once more than `d` points are present
- Degree slider (1–10); changing degree rebuilds the default knot vector
- t-parameter slider with live range label reflecting `[t_d, t_{n+1}]` of the current knot vector
- Knot vector editor: enter any non-decreasing comma-separated sequence and press Enter to apply; sequences that are too short are automatically extended, and non-decreasing order is enforced
- De Boor shells drawn at current t, one polygon per stage in a distinct color
- Evaluated point on the curve highlighted in white/blue at the tip of the shell hierarchy
- Control points labeled `P0, P1, ...` and are individually draggable; active drag point highlighted in yellow
- Clear button resets all control points and knot vector

## AI Assistance Disclosure

AI assistance was used to help navigate JUCE documentation for UI layout and to cross-check the De Boor shell indexing against the project specification during implementation.

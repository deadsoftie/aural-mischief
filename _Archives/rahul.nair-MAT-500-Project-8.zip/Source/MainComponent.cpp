#include "MainComponent.h"

#include "Project1.h"
#include "Project2.h"
#include "Project3.h"
#include "Project4.h"
#include "Project5.h"
#include "Project6.h"
#include "Project7.h"
#include "Project8.h"
#include "ProjectEC1.h"
#include "ProjectEC2.h"
#include "ProjectEC3.h"
#include "ProjectGP1.h"

MainComponent::MainComponent()
{
	projects.emplace_back(std::make_unique<Project8>());
	projects.emplace_back(std::make_unique<Project7>());
	projects.emplace_back(std::make_unique<ProjectGP1>());
	projects.emplace_back(std::make_unique<ProjectEC3>());
	projects.emplace_back(std::make_unique<ProjectEC2>());
	projects.emplace_back(std::make_unique<ProjectEC1>());
	projects.emplace_back(std::make_unique<Project6>());
	projects.emplace_back(std::make_unique<Project5>());
	projects.emplace_back(std::make_unique<Project4>());
	projects.emplace_back(std::make_unique<Project3>());
	projects.emplace_back(std::make_unique<Project2>());
	projects.emplace_back(std::make_unique<Project1>());

	addAndMakeVisible(menuBar);

	// Default to latest project
	switchToProject(0);

	setSize(1280, 720);
}

MainComponent::~MainComponent()
{
	menuBar.setModel(nullptr);
}

void MainComponent::paint(juce::Graphics &g)
{
	g.fillAll(juce::Colours::darkgrey);
}

void MainComponent::resized()
{
	auto area = getLocalBounds();

	auto menuArea = area.removeFromTop(24);
	menuBar.setBounds(menuArea);

	if (activeView)
		activeView->setBounds(area);
}

juce::StringArray MainComponent::getMenuBarNames()
{
	return {"Projects", "EC Projects", "Grad Project"};
}

juce::PopupMenu MainComponent::getMenuForIndex(int topLevelMenuIndex, const juce::String&)
{
	juce::PopupMenu menu;

	for (int i = 0; i < static_cast<int>(projects.size()); ++i)
	{
		const auto name = projects[i]->getName();
		const bool isEC = name.startsWith("EC-");
		const bool isGP = name.startsWith("GP-");

		if ((topLevelMenuIndex == 0 && !isEC && !isGP) ||
			(topLevelMenuIndex == 1 && isEC) ||
			(topLevelMenuIndex == 2 && isGP))
			menu.addItem(ProjectBaseId + i, name, true, i == currentProjectIndex);
	}

	return menu;
}

void MainComponent::menuItemSelected(int menuItemID, int)
{
	if (menuItemID >= ProjectBaseId)
	{
		const int idx = menuItemID - ProjectBaseId;
		switchToProject(idx);
	}
}

void MainComponent::switchToProject(int index)
{
	if (index < 0 || index >= static_cast<int>(projects.size()))
		return;

	currentProjectIndex = index;

	if (activeView)
	{
		removeChildComponent(activeView.get());
		activeView.reset();
	}

	activeView = projects[index]->createView();
	addAndMakeVisible(*activeView);

	resized();
	repaint();
}

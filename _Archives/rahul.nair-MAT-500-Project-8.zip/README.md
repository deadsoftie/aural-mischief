# Project 8 – 3D Bézier Curve Visualization

Rahul Nair (rahul.nair@digipen.edu)

## Overview

This project extends Project 2 into three dimensions. Bézier curves are evaluated in 3D using the same mathematical foundation — the core algorithms (De Casteljau NLI, BB-form, Midpoint Subdivision) are dimension-agnostic and operate unchanged on 3D control points. The primary new engineering concerns are perspective projection, an orbit camera, and 3D point manipulation.

## Running the Project

Double-click the `.exe` file to launch the application.

## Architecture

The application follows the same modular pattern as Project 2:

- A UI/controller component manages:
  - Degree selection (up to 20)
  - Evaluation method selection
  - Parameter t control
  - Reset camera / clear actions
  - Coordinate panel for precise point editing (X, Y, Z text fields)
- A dedicated 3D canvas component encapsulates:
  - 3D control point management and mouse interaction
  - Perspective projection (spherical orbit camera)
  - Curve evaluation and rendering in projected screen space
  - Method-specific rendering (De Casteljau shells projected into 3D view)

## Camera

The camera uses spherical coordinates (azimuth, elevation, distance) around a pivot point. Projection is standard perspective: world points are transformed into camera space, then divided by depth and scaled by focal length to produce screen coordinates.

## Features

- All three Project 2 evaluation methods extended to 3D:
  - Nested Linear Interpolation (De Casteljau's Algorithm)
  - Bernstein Basis (BB-form) Evaluation
  - Midpoint Subdivision
- Orbit camera via right-drag; zoom via scroll wheel
- 3D control point dragging:
  - Left-drag: moves point in the screen-aligned plane (camera right/up axes)
  - Shift + left-drag: moves point along the world Y axis only
- New point placement by unprojecting the click ray onto the world Y = 0 plane
- Coordinate panel: select a point to see and edit its exact X, Y, Z values
- De Casteljau shells and intermediate points rendered in projected 3D space
- World axis indicators (X/Y/Z) and reference grid for spatial orientation
- Camera state HUD (azimuth, elevation, distance)

## AI Assistance Disclosure

AI assistance was used to speed up navigation of the JUCE documentation, specifically to identify suitable UI components and layout approaches during development.

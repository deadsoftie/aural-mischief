# Project 6 – De Boor Algorithm for Polynomial Curves

Rahul Nair (rahul.nair@digipen.edu)

## Overview

This project is an interactive C++ application built using the JUCE framework to visualize and compare two equivalent representations of a single polynomial curve: the standard Bernstein/Bezier form and the De Boor form obtained via a spread knot sequence.

Users click to place control points incrementally, observing the Bezier curve rendered in real time via De Casteljau NLI. Switching to De Boor Mode converts the representation using the polar form, displaying the equivalent De Boor control polygon and curve. Both representations always describe the same underlying polynomial. Switching back to Bezier Mode reconstructs the Bezier control points from the current De Boor points via the inverse blossom, so the curve is preserved across mode switches in both directions.

## Running the Project

Double-click the `.exe` file to launch the application.

## Building the Project

Using the `Source` folder provided, generate a project using the JUCE Projucer and build from any compatible IDE.

## Architecture

The application follows the same modular, component-based structure as the previous projects:

- A UI/controller component manages user-facing controls:
  - Degree slider (`d`, range 1–20)
  - Mode drop-down ("Bezier Mode" / "De Boor Mode")
  - Clear button (resets all control points)
  - Knot sequence display (read-only, updates live)

- A single rendering and interaction component (`DeBoorPolyCanvas`) encapsulates:
  - Bezier and De Boor control point placement and drag interaction
  - De Casteljau NLI curve evaluation (Bezier mode)
  - De Boor NLI curve evaluation (De Boor mode)
  - Polar form computation (Bezier → De Boor)
  - Inverse blossom computation (De Boor → Bezier)

## Mathematics

### Bezier Mode

With `n` control points placed, the curve of effective degree `d = n - 1` is:

```
γ(t) = Σ_{i=0}^{d} P_i * B^d_i(t),   t ∈ [0, 1]
```

where `B^d_i(t)` are the Bernstein polynomials of degree `d`. The corresponding knot sequence shown is the clamped form:

```
[0, 0, ..., 0, 1, 1, ..., 1]   (d+1 zeros, d+1 ones)
```

Evaluation uses the De Casteljau (NLI) algorithm: at each stage `r`, blend adjacent points with weights `(1-t)` and `t`. After `d` stages the single remaining point is `γ(t)`.

### Polar Form

The polar form `F[u_1, ..., u_d]` is the unique symmetric multilinear function satisfying `F[t, t, ..., t] = γ(t)`. It is computed by applying the De Casteljau blend `d` times, using a different fixed argument `u_k` at each stage:

```
P^[0]_i = P_i
P^[k]_i = (1 - u_k) * P^[k-1]_i + u_k * P^[k-1]_{i+1}
F[u_1, ..., u_d] = P^[d]_0
```

### Spread Knot Sequence and De Boor Control Points

Selecting "De Boor Mode" builds the length-`2d+2` spread knot sequence:

```
t_i = (i - d) / 10         for i = 0, ..., d     (values -d/10 to 0)
t_{d+1} = 1
t_i = 1 + (i - d - 1) / 10  for i = d+2, ..., 2d+1
```

The De Boor control points `Q_0, ..., Q_d` are obtained from the polar form:

```
Q_i = F[t_{i+1}, t_{i+2}, ..., t_{i+d}],   i = 0, ..., d
```

### De Boor Algorithm

For `t ∈ [0, 1]`, starting from `Q^[0]_i = Q_i`, the algorithm performs `d` stages of nested linear interpolation using the spread knot values:

```
Q^[p]_i = α * Q^[p-1]_i + (1 - α) * Q^[p-1]_{i-1}

where  α = (t - t_i) / (t_{i+d-(p-1)} - t_i)
```

for `i = d, d-1, ..., p` at each stage `p = 1, ..., d`. The result `γ(t) = Q^[d]_d` is the identical polynomial as the Bezier form.

### Inverse Blossom (De Boor → Bezier)

When switching back to Bezier Mode, the Bezier control points are reconstructed from the current De Boor points using the multi-parameter blossom:

```
P_j = F_Q [ 0^(d-j),  1^j ]
```

This is computed by running the De Boor recurrence for `d` stages, using `u = 0` for the first `(d - j)` stages and `u = 1` for the remaining `j` stages. The result is that switching modes in either direction never shifts the visible curve.

## Features

- Control points placed by clicking; curve renders incrementally from the second point onward
- Knot sequence display updates live to match the effective degree of the rendered curve
- Mode drop-down switches between Bezier Mode and De Boor Mode (requires ≥ 2 points to enter De Boor Mode)
- Switching to De Boor Mode computes De Boor control points via polar form evaluation
- Additional points can be placed in De Boor Mode directly on the canvas
- Both control polygons visible simultaneously in De Boor Mode (Bezier polygon dimmed)
- De Boor control points are independently draggable in De Boor Mode
- Switching back to Bezier Mode reconstructs P from the current Q via the inverse blossom — curve is preserved with no shift
- Adjustable degree `d` (1–20); changing degree resets all points and knot sequence

## AI Assistance Disclosure

AI assistance was used to help navigate JUCE documentation for UI component layout and to cross-check inverse blossom reconstruction against the project specification during implementation.

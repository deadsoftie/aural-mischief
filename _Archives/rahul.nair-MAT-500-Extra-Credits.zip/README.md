# Extra Credit Projects – EC-1, EC-2, EC-3

Rahul Nair (rahul.nair@digipen.edu)

---

## EC-1 – Hermite Interpolation (Osculation)

### Overview

EC-1 extends the Newton interpolating polynomial (Project 3) to support derivative conditions at each node. This is called osculation, or Hermite interpolation. A point carrying `m` derivative conditions causes its parameter value to appear `m + 1` times in the expanded divided-difference table, which is the confluent (coalescent) form of Newton interpolation. The resulting polynomial interpolates both position and all specified derivatives simultaneously.

Derivative conditions can be assigned graphically using a tangent-drag mode triggered from a right-click context menu, or numerically through an input dialog. Higher-order derivatives (second, third) are entered through a dedicated dialog. As conditions are added or changed the curve redraws in real time.

### Architecture

| File | Role |
|------|------|
| `ProjectEC1.h` | Thin `IProject` entry; instantiates `ProjectEC1Component` |
| `ProjectEC1Component.h/.cpp` | Host component; toolbar with Clear Points and Clear Derivatives buttons |
| `HermiteInterpCanvas.h/.cpp` | All rendering, interaction, and Hermite solver logic |

The canvas stores each node as a `HermitePoint` holding its screen position, parameter value `t`, first-derivative flag and slope `dy/dt`, and a map of higher-order y-derivatives. An `ExpandedNode` list is rebuilt whenever the data changes; the coalescent divided-difference algorithm then solves for Newton coefficients in both x and y, and the curve is drawn by evaluating the resulting parametric polynomial using Horner's method.

### Mathematics

#### Expanded Node Sequence

A node at parameter `t_i` that carries derivatives up to order `m` is repeated `m + 1` times in the expanded sequence. For the confluent divided difference at a repeated node:

```
[t_i, ..., t_i]  (k+1 copies)  =  f^(k)(t_i) / k!
```

For x (horizontal coordinate), `dx/dt = 1` is assumed at every node and all higher x-derivatives are zero. For y, the user-specified values `dy/dt`, `d²y/dt²`, `d³y/dt³` are used directly.

#### Newton Interpolation via Horner's Method

Given the divided-difference coefficients `c[0], ..., c[n-1]` and node sequence `z[0], ..., z[n-1]`, the polynomial is evaluated as:

```
p(t) = c[0] + (t - z[0]) * (c[1] + (t - z[1]) * ( ... + (t - z[n-2]) * c[n-1]))
```

The parametric curve `(x(t), y(t))` is obtained by evaluating the same form separately for the x and y coefficient arrays.

### Features

- Left-click to place nodes (up to 12); drag to move any node in real time
- Right-click a node to open a context menu with four options:
  - **Set slope graphically** — activates tangent-drag mode; move the mouse to adjust the slope, scroll wheel for fine control, left-click to commit
  - **Set slope by value** — opens a numeric input dialog for `dy/dt`
  - **Set higher derivatives** — opens a dialog for `d²y/dt²` and `d³y/dt³`
  - **Clear derivatives** — removes all derivative conditions from that node
- Colour-coded dots: cyan = no derivative, green = has derivative, yellow = currently dragged or active tangent
- Tangent segment drawn at each node that has a first-derivative condition; arrowhead indicates positive-t direction
- Degree badge displayed beneath each node label showing which derivative orders are active
- **Clear Points** button resets the canvas; **Clear Derivatives** button strips all conditions while keeping node positions

> **Note:** The node limit is capped at 12. Allowing more nodes was reviewed with Prof. Klassen and determined to produce visually confusing results; the 12-node maximum was approved as the intended limit.

---

## EC-2 – Best Fit Line and Parabola

### Overview

EC-2 computes and displays the best-fit line and best-fit parabola to a set of user-placed input points. Points are placed by left-clicking anywhere on the canvas and can be repositioned by dragging or removed by right-clicking. The mode selector switches between displaying only the best-fit line and displaying both the line and the best-fit parabola.

The line search uses an iterative refinement strategy over the half-circle of directions `[0, π)`, minimizing the sum of perpendicular distances from the input points to a candidate line through the mean point. The parabola search uses the best-fit line to define a perpendicular bisector, partitions the points into two subsets, and searches for the optimal quadratic Bézier control point along each axis direction, selecting the family with the lower total cost.

### Architecture

| File | Role |
|------|------|
| `ProjectEC2.h` | Thin `IProject` entry; instantiates `ProjectEC2Component` |
| `ProjectEC2Component.h/.cpp` | Host component; toolbar with mode combo box and Clear All button |
| `BestFitCanvas.h/.cpp` | All rendering, mouse interaction, and fit computation |

The canvas maintains a flat `std::vector` of input points and a fit-state cache (`M`, `lineFitDir`, `bisDir`, control points `Q0/Q1/Q2`, cost values). `recompute()` is called after every point change and re-runs whichever fits are active.

### Mathematics

#### Best-Fit Line

Let `M = (x̄, ȳ)` be the centroid of all input points. For a line through `M` with unit direction `d(θ) = (cos θ, sin θ)`, the perpendicular distance from a point `p` to the line is:

```
dist(p, M, d) = |  (p - M) × d  |   (magnitude of 2D cross product)
```

The cost is:

```
S(θ) = Σ_i dist(p_i, M, d(θ))
```

The search covers `θ ∈ [0, π)` (lines have no orientation so a half-circle suffices). An iterative arc-refinement strategy with `kIter = 3` passes of `kSamples = 100` candidates per pass is used: after each pass the three best candidates are identified and the next pass densely samples the arc spanning those three angles.

#### Best-Fit Parabola

Once `Lbf` (direction `lineFitDir`) and the bisector `B` (direction `bisDir = ⊥ lineFitDir`) are known, two families of candidate parabolas are searched:

**Family A** — partition points by sign of `(p - M) · lineFitDir`; search for the Bézier control point `Q1` along `bisDir`.

**Family B** — partition points by sign of `(p - M) · bisDir`; search for `Q1` along `lineFitDir`.

For each family, the sub-means `M1` and `M2` of the two point subsets are used as the outer control points `Q0 = M1`, `Q2 = M2`. The middle control point is `Q1 = M + q1AxisDir · s`, where `s` is searched over the interval `[-4c, 4c]` and `c = max(|M1 - M|, |M2 - M|)`. The same iterative arc-refinement strategy used for the line is applied here.

Each candidate quadratic Bézier curve `C_t(Q0, Q1, Q2)` is pre-sampled at `kBezierSamples = 50` points and the cost is the sum of minimum point-to-segment distances from each input point to the nearest segment of the sampled curve. The family and `Q1` position with the lowest cost is selected as `Cbf`.

#### Quadratic Bézier Evaluation

```
C(t) = (1-t)² Q0 + 2(1-t)t Q1 + t² Q2,   t ∈ [0, 1]
```

### Features

- Left-click to place input points; drag to reposition; right-click to remove
- **Line** mode (default): displays the best-fit line `Lbf` and its perpendicular bisector `B`
- **Parabola** mode: additionally displays the best-fit quadratic Bézier `Cbf` and the sub-means `M1`, `M2`
- Mean point `M` shown as a labelled red dot
- Cost overlays `S(Lbf)` and `S(Cbf)` shown in the lower-left corner
- All geometry updates live as points are dragged

---

## EC-3 – Audio Signals with Bernstein Polynomials

> ⚠️ **Warning:** This project produces audio output immediately on launch. The default square wave (all coefficients = 1) can be loud. **Reduce your system volume before opening this project.** A Mute button is provided in the toolbar if needed.

### Overview

EC-3 is an audio-enhanced variant of Project 1. The visual interface is identical — the same graph canvas, degree slider (1–20), method selector (NLI / BB-form), and reset button — with two additions: a mute toggle and a frequency slider. As the user moves control points or changes degree, the synthesized waveform updates in real time and the new timbre plays immediately through the speakers.

The waveform is derived directly from the polynomial being displayed. One full cycle is formed from the first half-cycle `f(t)` (the displayed curve on `[0, 1]`) and an inverted mirror `g(t) = −f(2 − t)` as the second half-cycle. This piecewise function is normalized to a peak amplitude of 0.85 and fed continuously to the system audio output at the chosen frequency.

### Architecture

| File | Role |
|------|------|
| `ProjectEC3.h` | Thin `IProject` entry; instantiates `ProjectEC3Component` |
| `ProjectEC3Component.h/.cpp` | Host component; owns both the UI and the audio engine |

`ProjectEC3Component` implements `juce::AudioIODeviceCallback` directly and owns a `juce::AudioDeviceManager`. A lock-free double buffer (`wavetable[2]` + `std::atomic<int> readBuf`) separates the message-thread writer (`rebuildWavetable`) from the audio-thread reader (the callback). `GraphComponent::onCoeffChanged` is wired to `rebuildWavetable` so every drag event triggers an immediate wavetable rebuild.

### Mathematics

#### Waveform Construction

For the polynomial `f(t)` of degree `d` with control coefficients `a[0], ..., a[d]` (all in `[−3, 3]`), one audio cycle of `N` samples is built as:

```
sample[i] = f(t)        if  t < 1
           −f(2 − t)    if  t ≥ 1

where  t = 2i / N,   i = 0, 1, ..., N-1
```

The second half `g(t) = −f(2 − t)` is the first half evaluated in reverse and negated, giving a full cycle with `f(0) = a[0]` at the start and `g(2) = −a[0]` at the end (which wraps back to the start of the next cycle).

**Default case (all `a[i] = 1`):** `f(t) = 1` for all `t ∈ (0, 1)`, so the waveform is a square wave.

#### Normalization

```
scale = 0.85 / max_i |sample[i]|
sample[i] ← sample[i] × scale
```

Applied after filling the buffer. If all samples are zero the buffer is left silent.

#### Sampling Parameters

```
N = round(sampleRate / frequencyHz)
```

The device sample rate is read from `audioDeviceAboutToStart`. At the defaults (44 100 Hz sample rate, 441 Hz frequency) `N = 100` samples per cycle.

#### Lock-Free Double Buffer

`rebuildWavetable()` writes into the buffer not currently being read (`1 − readBuf`), then atomically stores the new index into `readBuf`. The audio callback reads `readBuf` once per block with `memory_order_acquire` and never blocks. A separate `std::atomic<bool> sizeChanged` flag signals the callback to wrap its phase index when the cycle length changes (e.g., after a frequency change).

### Features

- Full Project 1 interface (degree slider, NLI/BB method selector, reset button, draggable control points)
- **Mute** toggle button — silences output instantly without stopping the audio device
- **Frequency slider** — range 55–2000 Hz, default 441 Hz; adjusting it changes cycle length and rebuilds the wavetable in real time
- Waveform updates live on every control-point drag (not just on mouse release)
- Peak amplitude normalized to 0.85 at all times regardless of curve shape or degree
- Audio device opened automatically on construction and closed cleanly when switching away to another project

---

## AI Assistance Disclosure

AI assistance was used during implementation to help with JUCE audio device setup (`AudioDeviceManager`, `AudioIODeviceCallback`), the lock-free double-buffer pattern for real-time audio, and cross-checking the coalescent divided-difference recurrence for EC-1 against the project specification.

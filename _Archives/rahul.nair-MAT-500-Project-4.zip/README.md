# Project 4 – Interactive Natural Cubic Spline Visualization

Rahul Nair (rahul.nair@digipen.edu)

## Overview

This project is an interactive C++ application built using the JUCE framework to visualize parametric natural cubic spline curves constructed through interpolation.

The application allows users to define interpolation points directly on the canvas and generates a smooth parametric spline curve that passes exactly through those points. The spline is computed by solving a linear system in the truncated power basis with natural boundary conditions.

## Running the Project

Double-click the `.exe` file to launch the application.

## Building the Project

Using the `Source` folder that is provided just generate a project using the JUCE Projucer and run the project from any IDEs.

## Architecture

The application follows the same modular, component-based structure as the previous projects:

- A UI/controller component manages user-facing controls such as:
  - Segment count selection (up to 20)
  - Clear/reset functionality

- A dedicated rendering and interaction component encapsulates:
  - Interpolation point management and mouse interaction
  - Linear system construction and Gaussian elimination
  - Parametric spline evaluation and drawing

Spline mathematics and rendering behavior are isolated from UI controls, allowing clean separation between user interaction, linear algebra, and visualization.

## Mathematics

The natural cubic spline is constructed in the **truncated power basis**:

```
f(t) = a0 + a1*t + a2*t^2 + a3*t^3 + b1*(t-1)^3_+ + b2*(t-2)^3_+ + ... + b_{k-1}*(t-(k-1))^3_+
```

where the truncated power function is defined as:

```
(t - c)^3_+  =  0          if t < c
             =  (t - c)^3  if t >= c
```

Given `n = k+1` interpolation points at parameter values `t = 0, 1, 2, ..., k`, the spline vector space has dimension `n+2`. Two independent `(n+2) x (n+2)` linear systems are solved — one for `x(t)` and one for `y(t)` — with the following equations:

- **n interpolation conditions**: `f(i) = P_i` for each point `i = 0, ..., k`
- **2 natural boundary conditions**: `f''(0) = 0` and `f''(k) = 0`

The linear systems are solved using Gaussian elimination with partial pivoting.

## Features

- Interactive placement of interpolation points (up to 20 segments, i.e. 21 points)
- Real-time dragging of points with immediate spline update
- Parametric natural cubic spline generation using the truncated power basis
- Independent spline solution for `x(t)` and `y(t)`
- Natural boundary conditions enforced: zero second derivative at both endpoints
- Gaussian elimination with partial pivoting for numerical stability
- Segment count slider controlling the maximum number of interpolation points
- Visual labeling of interpolation points
- Polyline display connecting interpolation points for reference

The curve is evaluated over the parameter interval `[0, k]`, where `k` is the number of segments, ensuring the curve passes through every placed point.

## AI Assistance Disclosure

AI assistance was used to streamline navigation of the JUCE documentation, particularly in selecting appropriate UI components and layout strategies during development. Helped in refactoring some of the equations better for C++.

# Project 2 – Interactive Bézier Curve Visualization

Rahul Nair (rahul.nair@digipen.edu)

## Overview

This project is an interactive C++ application built using the JUCE framework to visualize Bézier curves defined by user-controlled control points.

The application allows users to construct and explore Bézier curves using multiple evaluation techniques while interactively manipulating control points and parameters.

## Running the Project

Double-click the `.exe` file to launch the application.

## Building the Project

Using the `Source` folder that is provided just generate a project using the JUCE Projucer and run the project from any IDEs.

## Architecture

The application follows a modular, component-based architecture:

- A UI/controller component manages all user-facing controls such as:
  - Degree selection (up to 20)
  - Evaluation method selection
  - Parameter t control
  - Reset / clear actions
- A dedicated rendering and interaction component encapsulates:
  - Control point management and mouse interaction
  - Curve evaluation and visualization
  - Method-specific rendering (e.g., shells for De Casteljau)

This separation cleanly isolates UI logic, curve mathematics, and rendering behavior, making the system easy to extend and reason about.

## Features

- Interactive placement and dragging of Bézier control points
- Support for Bézier curves up to degree 20
- Three curve evaluation methods:
  - Nested Linear Interpolation (De Casteljau’s Algorithm)
  - Bernstein Basis (BB-form) Evaluation
  - Midpoint Subdivision
- Real-time curve preview as control points are added
- Visualization of De Casteljau shells and intermediate points (NLI method only)
- Parameter slider for t∈[0,1] with a visual midpoint marker

## AI Assistance Disclosure

AI assistance was used to speed up navigation of the JUCE documentation, specifically to identify suitable UI components and layout approaches during development.
